fx_version 'cerulean'
game 'gta5'

author 'LennyModVanta'
description 'Freeze_System'
version '1.0.0'

client_script 'client.lua'